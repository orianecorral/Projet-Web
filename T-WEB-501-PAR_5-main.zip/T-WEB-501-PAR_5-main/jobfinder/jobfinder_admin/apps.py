from django.apps import AppConfig


class JobfinderAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jobfinder_admin'
