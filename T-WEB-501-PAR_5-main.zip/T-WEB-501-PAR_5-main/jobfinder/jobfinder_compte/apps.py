from django.apps import AppConfig


class JobfinderCompteConfig(AppConfig):
    name = 'jobfinder_compte'
